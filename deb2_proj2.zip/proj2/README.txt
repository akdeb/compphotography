Link to project: http://deb2.web.engr.illinois.edu/cs445/proj2/

Points I deserve:

Note: I used up one FREE DAY

10 points for the random patch texture synthesis with one result.
DONE

30 points for the overlapping patch texture synthesis with one result.
DONE

20 points for the seam finding texture synthesis with five results (including 
at least two from your own images).
DONE

30 points for texture transfer with at least two results (including at least one from your own images).
DONE

10 points for quality of results (e.g., 0=poor 5=average 10=great 15=amazing)
DONE

---------------------
100 POINTS DESERVED
